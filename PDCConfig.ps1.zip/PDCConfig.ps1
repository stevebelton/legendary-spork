# Run on DC

configuration PDCConfig
{
    param
    (
        [Parameter(Mandatory)]
        [String]$adminUsername,
        [Parameter(Mandatory)]
        [SecureString]$adminPassword,
        [Parameter(Mandatory)]
        [String]$domainName,
        [Parameter(Mandatory)]
        [String]$domainCredentialinitName,
        [Parameter(Mandatory)]
        [securestring]$domainCredentialinitPassword,
        [Parameter(Mandatory)]
        [String]$CBZoneName,
        [Parameter(Mandatory)]
        [String]$WebAccessZoneName,
        [Parameter(Mandatory)]
        [String]$CB1IP,
        [Parameter(Mandatory)]
        [String]$CB2IP,
        [Parameter(Mandatory)]
        [String]$webZoneWA1,
        [Parameter(Mandatory)]
        [String]$webZoneWA2
    )

    Import-DscResource -Module @{
        ModuleName    = 'xDnsServer'
        ModuleVersion = '1.7.0.0'
        GUID = '5f70e6a1-f1b2-4ba0-8276-8967d43a7ec2'
    }

    Import-DscResource -Module @{
        ModuleName    = 'xActiveDirectory'
        ModuleVersion = '2.16.0.0'
        GUID = '9FECD4F6-8F02-4707-99B3-539E940E9FF5'
    }

    $adminCreds = New-Object System.Management.Automation.PSCredential ($adminUsername, $adminPassword)
    $domainCredentialinit = New-Object System.Management.Automation.PSCredential ($domainCredentialinitName, $domainCredentialinitPassword)

    $username = $adminCreds.UserName -split '\\' | select -last 1
    $domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$username", $adminCreds.Password)

  
    Node localhost
    {

        xDnsServerPrimaryZone addCBPrimaryZone
        {
            Ensure        = 'Present'
            Name          = $CBZoneName
            ZoneFile      = 'ZoneName.dns'
            DynamicUpdate = 'NonsecureAndSecure'
        }

        xDnsServerPrimaryZone addWebAccessPrimaryZone
        {
            Ensure        = 'Present'
            Name          = $WebAccessZoneName
            ZoneFile      = 'ZoneName.dns'
            DynamicUpdate = 'NonsecureAndSecure'

            DependsOn = "[xDnsServerPrimaryZone]addCBPrimaryZone"

        }

        xDnsRecord CBZoneCB1
        {
            Name = "@"
            Target = $CB1IP
            Zone = $CBZoneName
	        Type = "ARecord"
            Ensure = "Present"

            DependsOn = "[xDnsServerPrimaryZone]addWebAccessPrimaryZone"
        }

        xDnsRecord CBZoneCB2
        {
            Name = "@"
            Target = $CB2IP
            Zone = $CBZoneName
	        Type = "ARecord"
            Ensure = "Present"

            DependsOn = "[xDnsRecord]CBZoneCB1"
        }

        xDnsRecord webZoneWA1
        {
            Name = "@"
            Target = $webZoneWA1
            Zone = $WebAccessZoneName
	        Type = "ARecord"
            Ensure = "Present"

            DependsOn = "[xDnsRecord]CBZoneCB2"
        }

        xDnsRecord webZoneWA2
        {
            Name = "@"
            Target = $webZoneWA2
            Zone = $WebAccessZoneName
	        Type = "ARecord"
            Ensure = "Present"

            DependsOn = "[xDnsRecord]webZoneWA1"
        }

        xADUser addUserAccount
        {
            DomainName = $domainName
            DomainAdministratorCredential = $domainCredentialinit
            UserName = "dadmin"
            Password = $domainCreds
            Ensure = "Present"
            DependsOn = "[xDnsRecord]webZoneWA2"

        }

        Script AddUserAccounttoDAGRoup
        {

            DependsOn = "[xADUser]addUserAccount"

            SetScript = {Add-ADGroupMember -Identity 'Domain Admins' -Members 'dadmin' -Credential $using:domainCredentialinit}

            TestScript = {
                if(((Get-ADGroupMember -Identity 'Domain Admins').Name -contains 'dadmin') -eq $false){return $false}else{return $true}
                
            }

            GetScript = { }
        }


    }

}

